export const AUTH = "http://auth:9701";
export const CLIENT_BE = "http://client-be:9702";
export const FARMER_BE = "http://farmer-be:9703";
export const ORDER_BE = "http://order-be:9704";
export const IMAGE = "http://image-server:9705";
