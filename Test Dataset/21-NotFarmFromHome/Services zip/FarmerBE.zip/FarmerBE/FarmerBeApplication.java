package NHHFFarmerBE.FarmerBE;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FarmerBeApplication {

	public static void main(String[] args) {
		SpringApplication.run(FarmerBeApplication.class, args);
		}

}