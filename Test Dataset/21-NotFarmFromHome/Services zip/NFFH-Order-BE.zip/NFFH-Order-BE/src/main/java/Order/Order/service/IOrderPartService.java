package Order.Order.service;

import Order.Order.entities.OrderPart;

public interface IOrderPartService {

    OrderPart create(OrderPart orderPart);
    
}
