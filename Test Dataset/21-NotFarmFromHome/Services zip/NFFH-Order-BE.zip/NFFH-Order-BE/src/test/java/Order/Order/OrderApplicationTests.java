package Order.Order;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

class OrderApplicationTests {

	@Test
	void contextLoads() {
	}

}
