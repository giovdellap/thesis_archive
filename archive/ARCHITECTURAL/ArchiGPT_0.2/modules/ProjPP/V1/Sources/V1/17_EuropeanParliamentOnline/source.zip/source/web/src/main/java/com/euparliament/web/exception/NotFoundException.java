package com.euparliament.web.exception;

public class NotFoundException extends Exception {

	private static final long serialVersionUID = 927526875957075419L;
	
	public NotFoundException() {
		super();
	}
	
}
