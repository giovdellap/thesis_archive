import { LoginResponse } from "../connectionTypes";

const loginResponse: LoginResponse = {
    token: "aaaaaeeeee",
    success: true,
    name: "Utente di Prova"
}

export { loginResponse };
