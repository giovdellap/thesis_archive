import React from 'react';
import SignupForm from '../Components/SignupForm';


function Signup() {
  return (
    <div>
      <div>
        <h2>Sign Up</h2>
        <SignupForm />
    </div>
    </div>
  );
}

export default Signup;
