export interface HomepageCard {
    title: string,
    seller: string,
    image: string,
    description: string,
    price: number,
    weight: boolean
}