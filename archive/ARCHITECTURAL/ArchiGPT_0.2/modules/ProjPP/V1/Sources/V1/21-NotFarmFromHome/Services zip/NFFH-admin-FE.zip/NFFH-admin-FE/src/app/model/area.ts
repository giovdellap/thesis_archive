export interface AreaReq {
  areaName: string
}

export interface AreasItemResponse {
  id: string,
  areaName: string
}

export interface NewAreaReq {
  areaName: string
}
