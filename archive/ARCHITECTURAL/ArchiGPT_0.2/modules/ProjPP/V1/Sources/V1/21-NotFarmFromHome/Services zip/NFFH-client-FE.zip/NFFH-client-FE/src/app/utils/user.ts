export interface User {
    name: string,
    token: string
}