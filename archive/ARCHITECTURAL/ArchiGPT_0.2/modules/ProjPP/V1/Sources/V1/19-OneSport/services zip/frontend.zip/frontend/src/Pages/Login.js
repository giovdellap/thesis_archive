import React from 'react';
import LoginForm from '../Components/LoginForm';

function Login() {
  return (
    <div>
      <h2>Log In</h2>
      <LoginForm />
    </div>
  );
}

export default Login;
