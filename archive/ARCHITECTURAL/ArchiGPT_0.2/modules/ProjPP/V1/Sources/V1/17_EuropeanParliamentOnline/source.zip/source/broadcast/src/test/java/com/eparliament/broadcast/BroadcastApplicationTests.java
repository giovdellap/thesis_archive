package com.eparliament.broadcast;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BroadcastApplicationTests {

	@Test
	void contextLoads() {
	}

}
