export interface userCookie {
    token : string, 
    id: string, 
    email: string, 
    username: string
}

export function getCookie(
    token: string,
    id: string,
    email: string,
    username: string) {
        return 
    }